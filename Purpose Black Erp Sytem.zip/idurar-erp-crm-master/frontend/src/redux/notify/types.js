export const START_LOADING = 'START_LOADING';
export const FINISH_LOADING = 'FINISH_LOADING';
export const UPDATE_UI = 'UPDATE_UI';
