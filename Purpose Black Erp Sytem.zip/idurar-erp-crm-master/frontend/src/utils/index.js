import tagColor from './tagColor';
import languages from './languages';
import currencies from './currenciesList';
export { tagColor, languages, currencies };
