const listBySettingKey = require('./listBySettingKey');
const readBySettingKey = require('./readBySettingKey');
const listAllSetting = require('./listAllSetting');

module.exports = { listAllSetting, listBySettingKey, readBySettingKey };
